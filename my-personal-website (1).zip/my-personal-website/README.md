# my personal website;)

A Pen created on CodePen.io. Original URL: [https://codepen.io/syethescientist/pen/yyBXxzx](https://codepen.io/syethescientist/pen/yyBXxzx).

